#!/usr/bin/python3

import os
import sys
import subprocess
import fnmatch
import itertools
from . import xlets_meta
from . import ansi_colors

from .terminal import TerminalApp
from gi.repository import GLib
from subprocess import Popen

Ansi = ansi_colors.ANSIColors()
env = os.environ.copy()
home = os.path.expanduser("~")

# Keeping this variable here so I don't have to use ugly indentation inside functions.
git_log_cmd = 'git log --grep=General --invert-grep --pretty=format:"\
- **Date:** %aD%n\
- **Commit:** [%h](https://github.com/Odyseus/CinnamonTools/commit/%h)%n\
- **Author:** %aN%n\`\`\`%n%s%n%b%n\`\`\`%n%n***%n" \
-- {relative_xlet_path} {append_or_override} "{tmp_log_path}"'


class XletsHelper():

    def __init__(self, root_path):
        super(XletsHelper, self).__init__()
        self.root_path = root_path
        self.xlets_meta = xlets_meta.XletsMeta(root_path=root_path)

    def generate_meta_file(self):
        xlets_meta.generate_meta_file(self.root_path)

    def compare_xlets(self, compare_applets=True, compare_extensions=True):
        user_xlets_path = os.path.join(home, ".local", "share", "cinnamon")

        for xlet in self.xlets_meta.list:
            user_xlet_path = os.path.join(user_xlets_path, "%ss" % xlet["type"], xlet["uuid"])
            repo_xlet_path = os.path.join(self.root_path, "%ss" % xlet["type"], xlet["uuid"],
                                          "files", xlet["uuid"])

            if xlet["type"] == "applet" and not compare_applets:
                continue

            if xlet["type"] == "extension" and not compare_extensions:
                continue

            self.do_popen(cmd="meld %s %s 2>&1 &" % (user_xlet_path, repo_xlet_path),
                          cwd=self.root_path,
                          do_wait=False,
                          do_log=False)

    def check_set_permission(self, set_exec=False):
        py_list = locate("*.py", self.root_path)
        sh_list = locate("*.sh", self.root_path)

        for p in itertools.chain(py_list, sh_list):
            if "/tools/" not in p and not is_exec(p):
                print(Ansi.YELLOW_BOLD("Not an executable: %s" % p[len(self.root_path):]))

                if set_exec:
                    print(Ansi.GREEN_BOLD("Setting it as such..."))
                    os.chmod(p, 0o755)

    def create_changelogs(self):
        print(Ansi.YELLOW_BOLD("Generating change logs..."))

        logs_storage = os.path.join(self.root_path, "tmp", "changelogs")
        changelog_sanitizer_path = os.path.join(self.root_path, "tools",
                                                "changelog_handler", "changelog_sanitizer.py")

        GLib.mkdir_with_parents(logs_storage, 0o755)

        for xlet in self.xlets_meta.list:
            print(Ansi.GREEN_BOLD("Generating change log for %s..." % xlet["name"]))

            xlet_root_folder = get_parent_dir(xlet["meta-path"], 2)
            tmp_log_path = os.path.join(logs_storage, xlet["uuid"] + ".md")

            # Generate change log from current repository paths.

            self.do_popen(cmd=git_log_cmd.format(relative_xlet_path="./" + xlet["type"] + "s/" + xlet["uuid"],
                                                 append_or_override=">",
                                                 tmp_log_path=tmp_log_path),
                          cwd=self.root_path)

            # Generate change log from old repository paths (before repository rearrangement).
            # Then append them to the previously generated change log.
            self.do_popen(cmd=git_log_cmd.format(relative_xlet_path="./" + xlet["type"].capitalize() + "s/" + xlet["uuid"],
                                                 append_or_override=">>",
                                                 tmp_log_path=tmp_log_path),
                          cwd=self.root_path)

            # Sanitize and clean up formatting of the change logs and
            # copy them to their final destinations.
            self.do_popen(cmd='%s "%s" "%s" "%s/CHANGELOG.md"' % (changelog_sanitizer_path,
                                                                  xlet["name"],
                                                                  tmp_log_path,
                                                                  xlet_root_folder),
                          cwd=xlet_root_folder)

    def update_pot_files(self):
        print(Ansi.YELLOW_BOLD("Starting POT files update..."))

        for xlet in self.xlets_meta.list:
            xlet_folder_path = get_parent_dir(xlet["meta-path"], 0)

            if os.path.exists(xlet_folder_path):
                print(Ansi.GREEN_BOLD(
                    "Updating localization template for %s..." % xlet["name"]))

                self.do_popen(cmd="make-xlet-pot --all",
                              cwd=xlet_folder_path)

    def create_localized_help(self):
        print(Ansi.YELLOW_BOLD("Starting localized help creation..."))

        for xlet in self.xlets_meta.list:
            script_folder_path = get_parent_dir(xlet["meta-path"], 2)
            script_file_path = os.path.join(script_folder_path, "create_localized_help.py")

            if os.path.exists(script_file_path):
                print(Ansi.GREEN_BOLD("Creating localized help for %s..." % xlet["name"]))

                self.do_popen(cmd="%s -p" % script_file_path,
                              cwd=script_folder_path)

    def render_main_site(self, working_directory, from_vte=False):
        print(Ansi.YELLOW_BOLD("Starting rendering of main site..."))

        if from_vte:
            term = TerminalApp(app_title="Render main site",
                               app_command="./tools/helper_shell_scripts/helper_shell_scripts.sh render-main-site",
                               working_directory=working_directory,
                               app_info_label="",
                               sub_id="render-main-site")
            term.run()
        else:
            # Passing a list instead of a string is the recommended.
            # I would do so if it would freaking work!!!
            # Always one step forward and two steps back with Python!!!
            subprocess.call("./tools/helper_shell_scripts/helper_shell_scripts.sh render-main-site",
                            shell=True,
                            stdout=subprocess.PIPE,
                            cwd=working_directory)

    def clone_wiki(self):
        print(Ansi.YELLOW_BOLD("Cloning repository's wiki..."))

        self.do_popen(cmd="git clone https://github.com/Odyseus/CinnamonTools.wiki.git &",
                      cwd=os.path.join(self.root_path, "docs"))

    def generate_trans_stats(self):
        print(Ansi.YELLOW_BOLD("Generating translation statistics..."))

        self.do_popen(cmd="./tools/helper_shell_scripts/helper_shell_scripts.sh generate-trans-stats &",
                      cwd=self.root_path)

    def create_packages(self):
        print(Ansi.YELLOW_BOLD("Creating xlets packages..."))

        self.do_popen(cmd="./tools/helper_shell_scripts/helper_shell_scripts.sh create-packages &",
                      cwd=self.root_path)

    def do_popen(self, cmd, cwd, do_wait=True, do_log=True):
        try:
            po = Popen(cmd,
                       shell=True,
                       stdout=subprocess.PIPE,
                       stdin=subprocess.PIPE,
                       universal_newlines=True,
                       env=env,
                       cwd=cwd)

            if do_wait:
                po.wait()

            if do_log:
                output, error_output = po.communicate()

                if po.returncode:
                    print(Ansi.RED_BOLD(error_output))
                else:
                    print(Ansi.GREEN_BOLD(output))
        except OSError as err:
            print(Ansi.RED_BOLD("Execution failed"), err, file=sys.stderr)


def get_parent_dir(fpath, go_up=0):
    """get_parent_dir

    Extract the path of the parent directory of a file path.

    Arguments:
        fpath {string} -- The full path to a file.

    Keyword Arguments:
        go_up {number} -- How many directories to go up. (default: {0})

    Returns:
        [string] -- The new path to a directory.
    """
    dir_path = os.path.dirname(fpath)

    if go_up >= 1:
        for x in range(0, int(go_up)):
            dir_path = os.path.dirname(dir_path)

    return dir_path


def is_exec(fpath):
    return os.path.isfile(fpath) and os.access(fpath, os.X_OK)


def locate(pattern, root_path):
    """Locate all files matching supplied file name pattern in and below
    supplied root directory."""
    for path, dirs, files in os.walk(os.path.abspath(root_path)):
        for filename in fnmatch.filter(files, pattern):
            yield os.path.join(path, filename)
