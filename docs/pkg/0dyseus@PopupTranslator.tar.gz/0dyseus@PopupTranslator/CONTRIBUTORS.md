## Contributors/Mentions

- **[NikoKrause](https://github.com/NikoKrause):** German localization and bug reports.
- **[Radek71](https://github.com/Radek71):** Czech localization and bug reports.
- **[muzena](https://github.com/muzena):** Croatian localization.
- **[giwhub](https://github.com/giwhub):** Chinese localization.
- **[eson57](https://github.com/eson57):** Swedish localization.
- **[Ilis](https://github.com/Ilis):** Russian localization.
