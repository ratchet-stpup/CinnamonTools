## Contributors/Mentions

- **[bsaleil](https://github.com/bsaleil):**: Author of the gnome-shell extension called [Todo list](https://github.com/bsaleil/todolist-gnome-shell-extension).
- **[Thomas Moreau](https://github.com/tomMoral):** Author of the gnome-shell extension called [Section Todo List](https://github.com/tomMoral/ToDoList).
- **[eson57](https://github.com/eson57):** Swedish localization.
- **[giwhub](https://github.com/giwhub):** Chinese localization.
