## Contributors/Mentions

- **[buzz](https://github.com/buzz):** Bug fixes.
- **[muzena](https://github.com/muzena):** Croatian localization.
- **[giwhub](https://github.com/giwhub):** Chinese localization.
- **[eson57](https://github.com/eson57):** Swedish localization.
