## Contributors/Mentions

- **[Radek71](https://github.com/Radek71):** Czech localization.
- **[muzena](https://github.com/muzena):** Croatian localization.
- **[giwhub](https://github.com/giwhub):** Chinese localization.
- **[eson57](https://github.com/eson57):** Swedish localization.
