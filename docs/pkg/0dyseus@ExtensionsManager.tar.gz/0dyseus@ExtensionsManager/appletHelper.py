#!/usr/bin/python2

import os
import argparse
import gettext
import gi
import re
import json
import subprocess
import sys
gi.require_version("Gtk", "3.0")
from gi.repository import Gio, Gtk

home = os.path.expanduser("~")

SETTING_TYPE_NONE = 0
SETTING_TYPE_INTERNAL = 1
SETTING_TYPE_EXTERNAL = 2
curr_ver = subprocess.check_output(["cinnamon", "--version"]).splitlines()[0].split(" ")[1]
translations = {}


def find_extension_subdir(directory):
    largest = [0]
    curr_a = curr_ver.split(".")

    for subdir in os.listdir(directory):
        if not os.path.isdir(os.path.join(directory, subdir)):
            continue

        if not re.match(r'^[1-9][0-9]*\.[0-9]+(\.[0-9]+)?$', subdir):
            continue

        subdir_a = subdir.split(".")

        if cmp(subdir_a, curr_a) <= 0 and cmp(largest, subdir_a) <= 0:
            largest = subdir_a

    if len(largest) == 1:
        return directory
    else:
        return os.path.join(directory, ".".join(largest))


def translate(uuid, string):
    # Check for a translation for this extension
    if uuid not in translations:
        try:
            translations[uuid] = gettext.translation(uuid, home + "/.local/share/locale").gettext
        except IOError:
            try:
                translations[uuid] = gettext.translation(uuid, "/usr/share/locale").gettext
            except IOError:
                translations[uuid] = None

    # Do not translate whitespaces
    if not string.strip():
        return string

    if translations[uuid]:
        result = translations[uuid](string)

        try:
            result = result.decode("UTF-8")
        except:
            result = result

        if result != string:
            return result

    return gettext.gettext(string)


class ExtensionsManager:

    def __init__(self):
        self.settings = Gio.Settings.new("org.cinnamon")
        self.enabled_extensions = self.settings.get_strv("enabled-extensions")
        self.all_extensions = {}

    def list_extensions(self):
        self.load_extensions_in(directory=('/usr/share/cinnamon/extensions'), do_return=False)
        self.load_extensions_in(
            directory=('%s/.local/share/cinnamon/extensions') % (home), do_return=True)

    def load_extensions_in(self, directory=False, do_return=False):
        if not (os.path.exists(directory) and os.path.isdir(directory)):
            return

        try:
            extensions = os.listdir(directory)
            for extension in extensions:
                extension_dir = "%s/%s" % (directory, extension)
                try:
                    if not (os.path.exists("%s/metadata.json" % extension_dir)):
                        continue

                    json_data = open("%s/metadata.json" % extension_dir).read()
                    setting_type = 0
                    data = json.loads(json_data)
                    extension_uuid = data["uuid"]
                    extension_name = translate(data["uuid"], data["name"])
                    extension_description = translate(data["uuid"], data["description"])

                    try:
                        extension_role = data["role"]
                    except KeyError:
                        extension_role = None
                    except ValueError:
                        extension_role = None

                    try:
                        hide_config_button = data["hide-configuration"]
                    except KeyError:
                        hide_config_button = False
                    except ValueError:
                        hide_config_button = False

                    if "multiversion" in data and data["multiversion"]:
                        extension_dir = find_extension_subdir(extension_dir)

                    try:
                        ext_config_app = os.path.join(
                            extension_dir, data["external-configuration-app"])
                        setting_type = SETTING_TYPE_EXTERNAL
                    except KeyError:
                        ext_config_app = ""
                    except ValueError:
                        ext_config_app = ""

                    if os.path.exists("%s/settings-schema.json" % extension_dir):
                        setting_type = SETTING_TYPE_INTERNAL

                    # Not used for now.
                    # try:
                    #     last_edited = data["last-edited"]
                    # except KeyError:
                    #     last_edited = -1
                    # except ValueError:
                    #     last_edited = -1

                    # Not used for now.
                    # try:
                    #     schema_filename = data["schema-file"]
                    # except KeyError:
                    #     schema_filename = ""
                    # except ValueError:
                    #     schema_filename = ""

                    version_supported = False
                    try:
                        version_supported = curr_ver in data["cinnamon-version"] or curr_ver.rsplit(
                            ".", 1)[0] in data["cinnamon-version"]
                    except KeyError:
                        version_supported = True  # Don't check version if not specified.
                    except ValueError:
                        version_supported = True

                    if ext_config_app != "" and not os.path.exists(ext_config_app):
                        ext_config_app = ""

                    extension_image = None
                    if "icon" in data:
                        extension_icon = data["icon"]
                        theme = Gtk.IconTheme.get_default()
                        if theme.has_icon(extension_icon):
                            extension_image = extension_icon
                    elif os.path.exists("%s/icon.png" % extension_dir):
                        try:
                            extension_image = "%s/icon.png" % extension_dir
                        except:
                            extension_image = None

                    if extension_image is None:
                        theme = Gtk.IconTheme.get_default()
                        if theme.has_icon("cs-extensions"):
                            extension_image = "cs-extensions"

                    try:
                        self.all_extensions[extension_uuid] = {
                            "name": extension_name,
                            "uuid": extension_uuid,
                            "description": extension_description,
                            "image": extension_image,
                            "hide_config_button": hide_config_button,
                            "ext_config_app": ext_config_app,
                            # "schema_filename": schema_filename,  # Not used for now.
                            "setting_type": setting_type,
                            # "last_edited": last_edited,  # Not used for now.
                            "version_supported": version_supported,
                            "extension_dir": extension_dir
                        }
                    except Exception as detail:
                        print "Failed to load extension %s: %s" % (extension, detail)

                except Exception as detail:
                    print "Failed to load extension %s: %s" % (extension, detail)
                    continue

        finally:
            if do_return:
                print json.dumps(self.all_extensions)


def main(argv=None):
    # Use of arguments in case I want/need to add functionality to the script.
    parser = argparse.ArgumentParser(description='Helper script for Extensions Manager applet\
     for Cinnamon.')
    group = parser.add_mutually_exclusive_group(required=False)
    group.add_argument("--list",
                       dest="list",
                       action="store_true",
                       help="Returns a JSON string with a list of all installed extensions.")

    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    if args.list:
        ExtensionsManager().list_extensions()

if __name__ == '__main__':
    main()
