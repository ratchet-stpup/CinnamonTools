## Contributors/Mentions

- **[muzena](https://github.com/muzena):** Croatian localization.
- **[giwhub](https://github.com/giwhub):** Chinese localization.
