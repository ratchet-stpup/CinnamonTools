## Contributors/Mentions

- **[Eric Gach](https://github.com/BigE):**: Author of the gnome-shell extension called [Desk Changer](https://github.com/BigE/desk-changer).
- **[eson57](https://github.com/eson57):** Swedish localization.
- **[giwhub](https://github.com/giwhub):** Chinese localization.
