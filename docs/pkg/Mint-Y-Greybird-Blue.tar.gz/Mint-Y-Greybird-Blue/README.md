## Mint-Y-Greybird-Blue theme description

This theme is based on the default **Mint-Y** theme but instead of using the green color, I used a blue color (the same blue used by the Greybird theme). .

## Abandoned

## Change Log

##### 1.0
- Initial **and last** release.

