## Contributors/Mentions

- **[awamper](https://github.com/awamper):** Original author of the gnome-shell extension called [Text Translator](https://github.com/awamper/text-translator).
- **[gufoe](https://github.com/gufoe):** Author of the newer version of [Text Translator](https://github.com/gufoe/text-translator) gnome-shell extension.
- **[soimort](https://github.com/soimort):** Author of the [translate-shell script](https://github.com/soimort/translate-shell).
- **[muzena](https://github.com/muzena):** Croatian localization.
- **[giwhub](https://github.com/giwhub):** Chinese localization.
- **[Radek71](https://github.com/Radek71):** Czech localization and author of Thunderbolt theme.
- **[NikoKrause](https://github.com/NikoKrause):** German localization.
- **[eson57](https://github.com/eson57):** Swedish localization.
