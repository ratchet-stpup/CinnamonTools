## Contributors/Mentions

- **[muzena](https://github.com/muzena):** Croatian localization.
- **[giwhub](https://github.com/giwhub):** Chinese localization.
- **[Alan01](https://github.com/Alan01):** Danish localization.
