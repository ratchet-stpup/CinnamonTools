## Contributors/Mentions

- **[NikoKrause](https://github.com/NikoKrause):** Bug fixes and German localization.
- **[Radek71](https://github.com/Radek71):** Czech localization.
- **[muzena](https://github.com/muzena):** Croatian localization.
- **[giwhub](https://github.com/giwhub):** Chinese localization.
- **[lestcape](https://github.com/lestcape):** Some advanced features on this applet are based on his [Configurable Menu applet](https://github.com/lestcape/Configurable-Menu) applet.
- **[nooulaif](https://github.com/nooulaif):** Fuzzy search feature based on his [Sane Menu](https://cinnamon-spices.linuxmint.com/applets/view/258) applet.
- **Daniel Bruce:** Some icons used by this menu are from [Entypo pictograms](www.entypo.com).
- **[eson57](https://github.com/eson57):** Swedish localization.
