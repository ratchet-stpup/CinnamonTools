## Contributors/Mentions

- **[lestcape](https://github.com/lestcape):** He is the brain behind the popup menus and desktop tweaks.
- **[Radek71](https://github.com/Radek71):** Czech localization.
- **[muzena](https://github.com/muzena):** Croatian localization.
- **[mikhail-ekzi](https://github.com/mikhail-ekzi):** Author of the Cinnamon extension called [Custom Shadows](https://cinnamon-spices.linuxmint.com/extensions/view/43).
- **[Fatih Mete](https://github.com/fatihmete):** Author of the Cinnamon extension called [Cinnamon Maximus](https://cinnamon-spices.linuxmint.com/extensions/view/29).
- **[Luis Pabon](https://github.com/luispabon):** Author of the gnome-shell extension called [Maximus NG](https://github.com/luispabon/maximus-gnome-shell).
- **[Florian Muellner](https://github.com/fmuellner):** Author of the gnome-shell extension called [Auto Move Windows](https://extensions.gnome.org/extension/16/auto-move-windows/).
- **[Valentin Dimitrov](https://github.com/v-dimitrov):** Author of the gnome-shell extension called [Steal My Focus](https://github.com/v-dimitrov/gnome-shell-extension-stealmyfocus).
- **[awamper](https://github.com/awamper):** Author of the gnome-shell extension called [Window Demands Attention Shortcut](https://github.com/awamper/window-demands-attention-shortcut).
- **[giwhub](https://github.com/giwhub):** Chinese localization.
