## Contributors/Mentions

- **[Philipp Emanuel Weidmann](https://github.com/p-e-w):**: Author of the gnome-shell extension called [Argos](https://github.com/p-e-w/argos).
- **[giwhub](https://github.com/giwhub):** Chinese localization.
