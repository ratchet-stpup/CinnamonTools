const $ = imports.applet.__init__;
const _ = $._;

const Applet = imports.ui.applet;
const Settings = imports.ui.settings;
const Gio = imports.gi.Gio;
const GLib = imports.gi.GLib;
const Gtk = imports.gi.Gtk;
const St = imports.gi.St;
const PopupMenu = imports.ui.popupMenu;
const Lang = imports.lang;
const Mainloop = imports.mainloop;
const Main = imports.ui.main;
const Util = imports.misc.util;

function MyApplet(aMetadata, aOrientation, aPanel_height, aInstance_id) {
    this._init(aMetadata, aOrientation, aPanel_height, aInstance_id);
}

MyApplet.prototype = {
    __proto__: Applet.TextIconApplet.prototype,

    _init: function(aMetadata, aOrientation, aPanel_height, aInstance_id) {
        Applet.TextIconApplet.prototype._init.call(this, aOrientation, aPanel_height, aInstance_id);

        // Condition needed for retro-compatibility.
        // Mark for deletion on EOL.
        if (Applet.hasOwnProperty("AllowedLayout"))
            this.setAllowedLayout(Applet.AllowedLayout.BOTH);

        this.settings = new Settings.AppletSettings(this, aMetadata.uuid, aInstance_id);
        this._bindSettings();

        try {
            this.metadata = aMetadata;
            this.instance_id = aInstance_id;
            this.orientation = aOrientation;

            // This shouldn't be needed because it's executed by the Cinnamon's "applets module".
            // But it seems that when using multiversion option, the icons folder is looked at the
            // version sub-directory, not in the main applet folder.
            // And the multiversion annoyances keep piling up!!!
            Gtk.IconTheme.get_default().append_search_path(this.main_applet_dir + "/icons/");

            this._lineView = new $.ArgosLineView(this);
            this.actor.add_actor(this._lineView.actor);

            this.menuManager = new PopupMenu.PopupMenuManager(this);
            this.menu = new Applet.AppletPopupMenu(this, aOrientation);
            this.menuManager.addMenu(this.menu);

            this._file = null;
            this._isDestroyed = false;
            this._updateTimeout = 0;
            this._cycleTimeout = 0;
            this._updateRunning = false;
            this._processingFile = false;

            this._processFile();
            this._updateKeybindings();
            this._updateIconAndLabel();
            this._expandAppletContextMenu();
        } catch (aErr) {
            global.logError(aErr);
        }
    },

    _processFile: function() {
        if (this._processingFile)
            return;

        try {
            this._processingFile = true;
            let path = this.pref_file_path;

            if (/^file:\/\//.test(path))
                path = path.substr(7);

            if (GLib.file_test(path, GLib.FileTest.EXISTS) &&
                GLib.file_test(path, GLib.FileTest.IS_EXECUTABLE) &&
                !GLib.file_test(path, GLib.FileTest.IS_DIR)) {
                this._file = Gio.file_new_for_path(path);
            } else {
                this._file = null;
            }
        } finally {
            if (this._file !== null)
                this.update();

            this._processingFile = false;
        }
    },

    update: function() {
        if (this._updateTimeout > 0) {
            Mainloop.source_remove(this._updateTimeout);
            this._updateTimeout = 0;
        }

        this._update();
    },

    _update: function() {
        if (this._updateRunning)
            return;

        this._updateRunning = true;

        try {
            $.spawnWithCallback(null, [this._file.get_path()], null, 0, null,
                Lang.bind(this, function(standardOutput) {
                    if (this._isDestroyed)
                        return;

                    this._processOutput(standardOutput.split("\n"));

                    let updateInterval = this._getInterval();

                    if (updateInterval !== 0) {
                        this._updateTimeout = Mainloop.timeout_add_seconds(updateInterval, Lang.bind(this, function() {
                            this._updateTimeout = 0;
                            this._update();
                            return false;
                        }));
                    }

                    this._updateRunning = false;
                }));
        } catch (aErr) {
            global.logError("Unable to execute file '" + this._file.get_basename() + "': " + aErr);
            this._updateRunning = false;
        }
    },

    _getInterval: function() {
        let updateInterval = 0;
        let number = this.pref_update_interval;
        let unit = this.pref_update_interval_units;

        let factorIndex = "smhd".indexOf(unit);

        if (factorIndex >= 0 && /^\d+$/.test(number)) {
            let factors = [1, 60, 60 * 60, 24 * 60 * 60];
            updateInterval = parseInt(number, 10) * factors[factorIndex];
        }

        return updateInterval;
    },

    _processOutput: function(output) {
        try {
            let buttonLines = [];
            let dropdownLines = [];

            let dropdownMode = false;

            for (let i = 0; i < output.length; i++) {
                if (output[i].length === 0)
                    continue;

                let line = $.parseLine(output[i]);

                if (!dropdownMode && line.isSeparator) {
                    dropdownMode = true;
                } else if (dropdownMode) {
                    dropdownLines.push(line);
                } else {
                    buttonLines.push(line);
                }
            }

            this.menu.removeAll();

            if (this._cycleTimeout > 0) {
                Mainloop.source_remove(this._cycleTimeout);
                this._cycleTimeout = 0;
            }

            if (buttonLines.length === 0) {
                if (this.pref_show_script_name)
                    this._lineView.setMarkup(GLib.markup_escape_text(this._file.get_basename(), -1));
                else
                    this._lineView.setLine("");
            } else if (buttonLines.length === 1) {
                this._lineView.setLine(buttonLines[0]);
            } else {
                this._lineView.setLine(buttonLines[0]);
                let i = 0;
                this._cycleTimeout = Mainloop.timeout_add_seconds(3, Lang.bind(this, function() {
                    i++;
                    this._lineView.setLine(buttonLines[i % buttonLines.length]);
                    return true;
                }));

                for (let j = 0; j < buttonLines.length; j++) {
                    if (buttonLines[j].dropdown !== "false")
                        this.menu.addMenuItem(new $.ArgosMenuItem(this, buttonLines[j]));
                }
            }

            if (this.menu.numMenuItems > 0)
                this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

            let menus = [];
            menus[0] = this.menu;

            for (let i = 0; i < dropdownLines.length; i++) {
                let menu;
                if (dropdownLines[i].menuLevel in menus) {
                    menu = menus[dropdownLines[i].menuLevel];
                } else {
                    global.logError("Invalid menu level for line '" + dropdownLines[i].text + "'");
                    menu = this.menu;
                }

                let menuItem;

                if (dropdownLines[i].isSeparator) {
                    // Although not documented, BitBar appears to render additional "---" lines as separators
                    menuItem = new PopupMenu.PopupSeparatorMenuItem();
                } else if ((i + 1) < dropdownLines.length &&
                    dropdownLines[i + 1].menuLevel > dropdownLines[i].menuLevel) {
                    // GNOME Shell actually supports only a single submenu nesting level
                    // (deeper levels are rendered, but opening them closes the parent menu).
                    // Since adding PopupSubMenuMenuItems to submenus does not trigger
                    // an error or warning, this should be considered a bug in GNOME Shell.
                    // Once it is fixed, this code will work as expected for nested submenus.
                    let lineView = new $.ArgosLineView(this, dropdownLines[i]);
                    menuItem = new $.CustomSubMenuItem(this, lineView.actor);
                    menus[dropdownLines[i + 1].menuLevel] = menuItem.menu;
                } else if ((i + 1) < dropdownLines.length &&
                    dropdownLines[i + 1].menuLevel === dropdownLines[i].menuLevel &&
                    dropdownLines[i + 1].alternate === "true") {
                    menuItem = new $.ArgosMenuItem(this, dropdownLines[i], dropdownLines[i + 1]);
                    // Skip alternate line
                    i++;
                } else {
                    menuItem = new $.ArgosMenuItem(this, dropdownLines[i]);
                }

                menu.addMenuItem(menuItem);
            }

            // Moved the item to edit the script file to the applet's context menu.
        } catch (aErr) {
            global.logError(aErr);
        }
    },

    _expandAppletContextMenu: function() {
        let menuItem;

        // Choose script file
        menuItem = new PopupMenu.PopupIconMenuItem(
            _("Choose script"),
            "document-open",
            St.IconType.SYMBOLIC
        );
        menuItem.connect("activate", Lang.bind(this, function() {
            Util.spawn_async([this.metadata.path + "/appletHelper.py", "open"],
                Lang.bind(this, function(aOutput) {
                    let path = aOutput.trim();

                    if (!Boolean(path))
                        return;

                    // I don't know why this doesn't trigger the callback attached to the preference.
                    // That's why I added the call to this._processFile in here too.
                    // Just in case, I also added the this._processingFile check in case in some
                    // other versions of Cinnamon the callback it's triggered.
                    this.pref_file_path = path;
                    this._processFile();
                }));
        }));
        menuItem.tooltip = new $.MyTooltip(
            menuItem.actor,
            _("Choose a script file.")
        );
        this._applet_context_menu.addMenuItem(menuItem);

        // Refresh
        menuItem = new PopupMenu.PopupIconMenuItem(
            _("Refresh"),
            "view-refresh",
            St.IconType.SYMBOLIC
        );
        menuItem.connect("activate", Lang.bind(this, function() {
            if (this._file === null) {
                Main.notify(_(this.metadata.name),
                    _("Script file not set or it cannot be found."));
            } else {
                this.update();
            }
        }));
        menuItem.tooltip = new $.MyTooltip(
            menuItem.actor,
            _("This will execute on demand the script assigned to this applet for the purpose of refreshing its data.") + "\n" +
            _("This is only needed when there is no update interval set, so the update needs to be manual in case the script is edited.")
        );
        this._applet_context_menu.addMenuItem(menuItem);

        // Edit script
        menuItem = new PopupMenu.PopupIconMenuItem(
            _("Edit script"),
            "text-editor",
            St.IconType.SYMBOLIC
        );
        menuItem.connect("activate", Lang.bind(this, function() {
            if (this._file === null) {
                Main.notify(_(this.metadata.name),
                    _("Script file not set or it cannot be found."));
            } else {
                // The original Argos extension uses Gio.AppInfo.launch_default_for_uri
                // to open the script file. I prefer to stay away from non asynchronous functions.
                // Gio.AppInfo.launch_default_for_uri_async is still too new.
                Util.spawn_async(["xdg-open", this._file.get_path()], null);
            }
        }));
        menuItem.tooltip = new $.MyTooltip(
            menuItem.actor,
            _("Edit the script file with your prefered text editor.") + "\n" +
            _("After saving the changes made, the applet will update its data automatically if there is an interval set.") +
            _("Or the update could be done manually with the »Refresh« item on this applet context menu.")
        );
        this._applet_context_menu.addMenuItem(menuItem);

        // Help
        menuItem = new PopupMenu.PopupIconMenuItem(
            _("Help"),
            "dialog-information",
            St.IconType.SYMBOLIC
        );
        menuItem.tooltip = new $.MyTooltip(menuItem.actor, _("Open this applet help file."));
        menuItem.connect("activate", Lang.bind(this, function() {
            Util.spawn_async(["xdg-open", this.metadata.path + "/HELP.html"], null);
        }));
        this._applet_context_menu.addMenuItem(menuItem);
    },

    _bindSettings: function() {
        let bD = Settings.BindingDirection || null;
        let settingsArray = [
            [bD.IN, "pref_custom_icon_for_applet", this._updateIconAndLabel],
            [bD.IN, "pref_custom_label_for_applet", this._updateIconAndLabel],
            [bD.IN, "pref_show_script_name", this.update],
            [bD.IN, "pref_overlay_key", this._updateKeybindings],
            [bD.IN, "pref_animate_menu", null],
            [bD.IN, "pref_keep_one_menu_open", null],
            [bD.BIDIRECTIONAL, "pref_file_path", this._processFile],
            [bD.IN, "pref_default_icon_size", this.update],
            [bD.IN, "pref_update_interval", this.update],
            [bD.IN, "pref_update_interval_units", this.update],
            [bD.IN, "pref_terminal_emulator", null],
        ];
        let newBinding = typeof this.settings.bind === "function";
        for (let [binding, property_name, callback] of settingsArray) {
            // Condition needed for retro-compatibility.
            // Mark for deletion on EOL.
            if (newBinding)
                this.settings.bind(property_name, property_name, callback);
            else
                this.settings.bindProperty(binding, property_name, property_name, callback, null);
        }
    },

    _updateIconAndLabel: function() {
        try {
            if (this.pref_custom_icon_for_applet === "") {
                this.set_applet_icon_name("");
            } else if (GLib.path_is_absolute(this.pref_custom_icon_for_applet) &&
                GLib.file_test(this.pref_custom_icon_for_applet, GLib.FileTest.EXISTS)) {
                if (this.pref_custom_icon_for_applet.search("-symbolic") != -1)
                    this.set_applet_icon_symbolic_path(this.pref_custom_icon_for_applet);
                else
                    this.set_applet_icon_path(this.pref_custom_icon_for_applet);
            } else if (Gtk.IconTheme.get_default().has_icon(this.pref_custom_icon_for_applet)) {
                if (this.pref_custom_icon_for_applet.search("-symbolic") != -1)
                    this.set_applet_icon_symbolic_name(this.pref_custom_icon_for_applet);
                else
                    this.set_applet_icon_name(this.pref_custom_icon_for_applet);
                /**
                 * START mark Odyseus
                 * I added the last condition without checking Gtk.IconTheme.get_default.
                 * Otherwise, if there is a valid icon name added by
                 *  Gtk.IconTheme.get_default().append_search_path, it will not be recognized.
                 * With the following extra condition, the worst that can happen is that
                 *  the applet icon will not change/be set.
                 */
            } else {
                try {
                    if (this.pref_custom_icon_for_applet.search("-symbolic") != -1)
                        this.set_applet_icon_symbolic_name(this.pref_custom_icon_for_applet);
                    else
                        this.set_applet_icon_name(this.pref_custom_icon_for_applet);
                } catch (aErr) {
                    global.logError(aErr);
                }
            }
        } catch (aErr) {
            global.logWarning("Could not load icon file \"" + this.pref_custom_icon_for_applet + "\" for menu button");
        }

        if (this.pref_custom_icon_for_applet === "") {
            this._applet_icon_box.hide();
        } else {
            this._applet_icon_box.show();
        }

        if (this.orientation == St.Side.LEFT || this.orientation == St.Side.RIGHT) { // no menu label if in a vertical panel
            this.set_applet_label("");
        } else {
            if (this.pref_custom_label_for_applet !== "")
                this.set_applet_label(_(this.pref_custom_label_for_applet));
            else
                this.set_applet_label("");
        }

        this.update_label_visible();
    },

    update_label_visible: function() {
        // Condition needed for retro-compatibility.
        // Mark for deletion on EOL.
        if (typeof this.hide_applet_label !== "function")
            return;

        if (this.orientation == St.Side.LEFT || this.orientation == St.Side.RIGHT)
            this.hide_applet_label(true);
        else
            this.hide_applet_label(false);
    },

    _toggleMenu: function() {
        if (!this.menu.isOpen && this.menu.numMenuItems > 0)
            this.menu.open(this.pref_animate_menu);
        else
            this.menu.close(this.pref_animate_menu);
    },

    on_applet_clicked: function() {
        this._toggleMenu();
    },

    on_applet_removed_from_panel: function() {
        this._isDestroyed = true;

        if (this._updateTimeout > 0)
            Mainloop.source_remove(this._updateTimeout);

        if (this._cycleTimeout > 0)
            Mainloop.source_remove(this._cycleTimeout);

        Main.keybindingManager.removeHotKey("odyseus-argos-overlay-key-" + this.instance_id);

        this.menu.removeAll();
    },

    _updateKeybindings: function() {
        Main.keybindingManager.removeHotKey("odyseus-argos-overlay-key-" + this.instance_id);

        if (this.pref_overlay_key !== "") {
            Main.keybindingManager.addHotKey(
                "odyseus-argos-overlay-key-" + this.instance_id,
                this.pref_overlay_key,
                Lang.bind(this, function() {
                    if (!Main.overview.visible && !Main.expo.visible)
                        this._toggleMenu();
                })
            );
        }
    }
};

function main(aMetadata, aOrientation, aPanel_height, aInstance_id) {
    return new MyApplet(aMetadata, aOrientation, aPanel_height, aInstance_id);
}
